﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    /// <summary>
    /// Enumerador de status de ordens
    /// </summary>
    public enum OrdemStatusEnum
    {
        NOVA = 0,
        PARCIALMENTEEXECUTADA = 1,
        EXECUTADA = 2,
        CANCELADA = 4,
        SUBSTITUIDA = 5,
        REJEITADA = 8,
        SUSPENSA = 9,
        PENDENTE = 10,
        ENVIADAPARAOROTEADORDEORDENS = 100,
        ENVIADAPARAOCANAL = 101,
        ENVIADAPARAABOLSA = 102
    }
}


