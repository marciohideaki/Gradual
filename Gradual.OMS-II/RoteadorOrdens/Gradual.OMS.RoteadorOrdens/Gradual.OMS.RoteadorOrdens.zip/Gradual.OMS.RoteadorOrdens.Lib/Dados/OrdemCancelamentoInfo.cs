﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

using Gradual.OMS.RoteadorOrdens.Lib.Dados;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    [Serializable]
    public class OrdemCancelamentoInfo
    {
        /// <summary>
        /// Conta acordada entre a corretora e a instituição
        /// </summary>
        [Category("Cancelamento")]
        [Description("Conta acordada entre a corretora e a instituição")]
        public int Account { set; get; }

        /// <summary>
        /// ClOrdID da oferta que o cliente deseja cancelar
        /// </summary>
        [Category("Cancelamento")]
        [Description("ClOrdID da oferta que o cliente deseja cancelar")]
        public string OrigClOrdID { set; get; }

        /// <summary>
        /// ClOrdID da oferta que o cliente deseja cancelar
        /// </summary>
        [Category("Cancelamento")]
        [Description("OrderID atribuído pela BM&FBOVESPA à oferta que o cliente deseja cancelar")]
        public string OrderID { set; get; }

        /// <summary>
        /// Identificador único da solicitação de cancelamento, conforme atribuído pela instituição
        /// </summary>
        [Category("Cancelamento")]
        [Description("Identificador único da solicitação de cancelamento, conforme atribuído pela instituição")]
        public string ClOrdID { set; get; }

        /// <summary>
        /// Símbolo da ação
        /// </summary>
        [Category("Cancelamento")]
        [Description("Símbolo da ação")]
        public string Symbol { set; get; }

        /// <summary>
        /// Bovespa/BMF:
        /// Identificador do instrumento, conforme definido pela BMFBOVESPA. Para a lista 
        /// de instrumentos, consulte a mensagem correspondente (Security List).
        /// </summary>
        [Category("Identificação do Instrumento")]
        [Description("BMF: Identificador do instrumento, conforme definido pela BMFBOVESPA. Para a lista de instrumentos, consulte a mensagem correspondente (Security List).")]
        public string SecurityID { get; set; }

        /// <summary>
        /// Ponta da oferta a ser cancelada. 
        /// Valores aceitos:
        ///     1 = compra
        ///     2 = venda
        /// </summary>
        [Category("Cancelamento")]
        [Description("Ponta da oferta a ser cancelada.")]
        public OrdemDirecaoEnum Side { set; get; }

        /// <summary>
        /// Número de ações ou contratos da oferta
        /// </summary>
        [Category("Cancelamento")]
        [Description("Número de ações ou contratos da oferta")]
        public int OrderQty { set; get; }

        /// <summary>
        /// Código do canal em que a ordem sera executada
        /// </summary>
        [Category("Atributos")]
        [Description("Código do canal em que a ordem será executada.")]
        public int ChannelID { get; set; }

        /// <summary>
        /// Bolsa na qual a ordem será executada
        /// </summary>
        [Category("Atributos")]
        [Description("Bolsa na qual a ordem será executada. (BMF/BOVESPA)")]
        public string Exchange { get; set; }

    }
}
