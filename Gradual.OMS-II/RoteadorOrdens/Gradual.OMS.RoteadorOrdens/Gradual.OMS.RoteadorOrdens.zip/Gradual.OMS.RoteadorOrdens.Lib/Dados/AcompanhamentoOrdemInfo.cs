﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{

    /// <summary>
    /// <autor>Rafael Sanches Garcia</autor>
    /// <Descricao>
    /// Acompanhamento de ordens Bovespa.    
    /// </Descricao>
    /// <DataCriacao>{xml:cdata[date::datenow]}</DataCriacao>
    /// <![CDATA[AcompanhamentoOrdemIndo]]>
    /// </summary>

    [Serializable]
    public class AcompanhamentoOrdemInfo
    {
        #region [ Acompanhamento de Ordens ]

        /// <summary>
        /// Numero de controle da ordem formada por (CodigoCliente + DD/MM/YYYY hh:mm:ssss + 4 bytes numeros aleatorios )
        /// Este atributo é a chave primaria de uma ordem na corretora
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("(ClOrdId) Numero de controle gerado pelo canal corretora para identificacao da ordem na bolsa.")]
        public string NumeroControleOrdem {set;get;}
        
        /// <summary>
        /// Codigo do cliente que pediu a ordem
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Código do cliente que pediu a ordem")]
        public int CodigoDoCliente {set;get;}

       /// <summary>
       /// Identificador na ordem no canal bolsa ( Código de execucação da ordem na bovespa )
       /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Identificador na ordem no canal bolsa - ExchangeNumberId")]
        public string CodigoResposta {set;get;}

        /// <summary>
        /// Identificador na ordem no canal bolsa ( Código de execucação da ordem na bovespa )
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Identificador da execução no canal bolsa - TransactId")]
        public string CodigoTransacao {set;get;}

        /// <summary>
        /// Código do instrumento
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Código do instrumento")]
        public string Instrumento {set;get;}

        /// <summary>
        /// Identificador do instrumento, conforme definido pela BMFBOVESPA. Para a lista 
        /// de instrumentos, consulte a mensagem correspondente (Security List).
        /// </summary>
        [Category("Identificação do Instrumento")]
        [Description("BMF: Identificador do instrumento, conforme definido pela BMFBOVESPA. Para a lista de instrumentos, consulte a mensagem correspondente (Security List).")]
        public string SecurityID { get; set; }

        /// <summary>
        /// Canal de origem da ordem:
        /// 1 = BOVESPA
        /// 2 = BMF
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Canal de origem da ordem")]
        public int CanalNegociacao {set;get;}


        /// <summary>
        /// Direção da Ordem ( Compra / Venda )      
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Direção da ordem")]
        public OrdemDirecaoEnum Direcao {set;get;}

         /// <summary>
        /// Quantidade solicitada pelo cliente para execução de uma ordem de compra ou venda   
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Quantidade solicitada pelo cliente para execução de uma ordem de compra ou venda")]
        public int QuantidadeSoliciada {set;get;}

        /// <summary>
        /// Quantidade executada pela bolsa do total solicitado
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Quantidade executada pela bolsa do total solicitado")]
        public int QuantidadeExecutada {set;get;}

        /// <summary>
        /// Preco informado pelo cliente para a execução de uma ordem
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Preco informado pelo cliente para a execução de uma ordem")]
        public decimal Preco {set;get;}



        /// <summary>
        /// Status da execução ordem gerado pelo roteador FIX
        /// NOVA = 0,
        /// PARCIALMENTEEXECUTADA = 1,
        /// EXECUTADA = 2,
        /// CANCELADA = 4,
        /// SUBSTITUIDA = 5,
        /// REJEITADA   = 8,
        /// SUSPENSA    = 9,
        /// ENVIADAPARAOROTEADORDEORDENS = 100,
        /// ENVIADAPARAABOLSA            = 101
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Status da execução da ordem")]        
        public OrdemStatusEnum StatusOrdem {set;get;}

        
        /// <summary>
        /// Data de envio da ordem pelo cliente
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Data de envio da ordem pelo cliente")]
        public DateTime DataOrdemEnvio {set;get;}
            
        /// <summary>
        /// Data de atualização da ordem gerada pelo roteador
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Data de atualização da ordem gerada pelo roteador")]
        public DateTime DataAtualizacao {set;get;}

        /// <summary>
        /// Data de validade da ordem enviada pelo cliente
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Data de validade da ordem enviada pelo cliente")]
        public DateTime DataValidade {set;get; }

        /// <summary>
        /// Código de Rejeição
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Código de Rejeição")]
        public string CodigoRejeicao { set; get; }

        /// <summary>
        /// Descrição
        /// </summary>
        [Category("Acompanhamento de Ordens")]
        [Description("Descrição")]
        public string Descricao { set; get; }

        #endregion

        #region Construtor

        public AcompanhamentoOrdemInfo() { }
        
        public AcompanhamentoOrdemInfo(AcompanhamentoOrdemInfo pInfo)
        {
            this.CanalNegociacao = pInfo.CanalNegociacao;
            this.CodigoDoCliente = pInfo.CodigoDoCliente;
            this.CodigoResposta = pInfo.CodigoResposta;
            this.CodigoTransacao = pInfo.CodigoTransacao;
            this.DataAtualizacao = pInfo.DataAtualizacao;
            this.DataOrdemEnvio = pInfo.DataOrdemEnvio;
            this.DataValidade = pInfo.DataValidade;
            this.Direcao = pInfo.Direcao;
            this.Instrumento = pInfo.Instrumento;
            this.NumeroControleOrdem = pInfo.NumeroControleOrdem;
            this.Preco = pInfo.Preco;
            this.QuantidadeExecutada = pInfo.QuantidadeExecutada;
            this.QuantidadeSoliciada = pInfo.QuantidadeSoliciada;
            this.StatusOrdem = pInfo.StatusOrdem;
        }

        #endregion
    }
}
