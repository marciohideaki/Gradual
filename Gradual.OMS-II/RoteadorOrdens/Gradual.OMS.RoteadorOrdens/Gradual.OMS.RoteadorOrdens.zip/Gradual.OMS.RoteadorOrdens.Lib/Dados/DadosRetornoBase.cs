﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;


namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    /// <summary>
    /// Classe base para dados de retorno do Roteador de Ordens.
    /// </summary>

    public abstract class DadosRetornoBase
    {
        [Category("RoteadorDadosRetornoBase")]
        public DateTime DataResposta { get; set; }
        [Description("StackTrace da mensagem de erro")]
        public string StackTrace { get; set; }
        [Description("Status de retornada do roteamento da ordem")]
        public StatusRoteamentoEnum StatusResposta { get; set; }
        [Description("Ocorrências no roteamento da ordem")]
        public List<OcorrenciaRoteamentoOrdem> Ocorrencias { set; get; }

        public DadosRetornoBase()
        {
            DataResposta = DateTime.Now;
            Ocorrencias = new List<OcorrenciaRoteamentoOrdem>();
        }
    }
}
