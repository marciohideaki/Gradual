﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    /// <summary>
    /// Enumerador de direção da ordem: compra ou venda.
    /// </summary>
    [Serializable]
    public enum StatusRoteamentoEnum
    {
        Sucesso = 8,
        Erro = 1
    }
}
