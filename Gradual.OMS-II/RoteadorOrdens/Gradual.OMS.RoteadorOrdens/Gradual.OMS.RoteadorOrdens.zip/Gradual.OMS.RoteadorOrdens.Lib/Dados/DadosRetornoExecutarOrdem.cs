﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    public class DadosRetornoExecutarOrdem : DadosRetornoBase
    {
    }
}
