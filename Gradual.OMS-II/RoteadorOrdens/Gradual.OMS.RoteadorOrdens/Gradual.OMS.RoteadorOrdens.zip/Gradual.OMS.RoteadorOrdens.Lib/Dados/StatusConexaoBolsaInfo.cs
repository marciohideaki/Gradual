﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    [Serializable]
    [DataContract]
    public class StatusConexaoBolsaInfo
    {
        /// <summary>
        /// Bolsa - Codigo da Bolsa (BMF/BOVESPA)
        /// </summary>
        [DataMember]
        public string Bolsa { get; set; }

        /// <summary>
        /// Porta - Operador do Canal (300,310, etc)
        /// </summary>
        [DataMember]
        public int Operador { get; set; }

        /// <summary>
        /// Flag do estado da conexao
        /// </summary>
        [DataMember]
        public bool Conectado { get; set; }
    }
}
