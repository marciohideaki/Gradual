﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    public class OcorrenciaRoteamentoOrdem
    {
        public string Ocorrencia { set; get; }
        public DateTime DataHoraOcorrencia { set; get; }
    }
}
