﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Gradual.OMS.RoteadorOrdens.Lib.Dados
{
    public class OrdemCrossInfo
    {

        /// <summary>
        /// 
        /// </summary>
        public string CrossID { get; set; }

        /// <summary>
        /// Bovespa/BMF:
        /// Símbolo. A BMFBOVESPA exige que esse campo seja adequadamente preenchido. 
        /// Ele contém a forma inteligível do campo SecurityID, disponível na mensagem de 
        /// lista de instrumentos.
        /// ------------------------------------------------------------------------------
        /// Bovespa:
        /// Símbolo da ação
        /// </summary>
        [Category("Identificação do Instrumento")]
        [Description("BMF: Símbolo. A BMFBOVESPA exige que esse campo seja adequadamente preenchido. Ele contém a forma inteligível do campo SecurityID, disponível na mensagem de lista de instrumentos. | Bovespa: Símbolo da ação")]
        public string Symbol { get; set; }

        /// <summary>
        /// Bovespa/BMF:
        /// Símbolo. A BMFBOVESPA exige que esse campo seja adequadamente preenchido. 
        /// Ele contém a forma inteligível do campo SecurityID, disponível na mensagem de 
        /// lista de instrumentos.
        /// ------------------------------------------------------------------------------
        /// Bovespa:
        /// Símbolo da ação
        /// </summary>
        [Category("Origem do SecurityID")]
        [Description("BMF: Origem do campo FIX SecurityID")]
        public string SecurityIDSource { get; set; }

        /// <summary>
        /// Bovespa/BMF:
        /// Identificador do instrumento, conforme definido pela BMFBOVESPA. Para a lista 
        /// de instrumentos, consulte a mensagem correspondente (Security List).
        /// </summary>
        [Category("Identificação do Instrumento")]
        [Description("BMF: Identificador do instrumento, conforme definido pela BMFBOVESPA. Para a lista de instrumentos, consulte a mensagem correspondente (Security List).")]
        public string SecurityID { get; set; }


        /// <summary>
        /// BMF / Bovespa:
        /// Horário de execução / geração da ordem, expresso em UTC.
        /// Faz referencia à data referencia da mensagem base.
        /// </summary>
        [Category("New Order Single")]
        [Description("BMF / Bovespa: Horário de execução / geração da ordem, expresso em UTC")]
        public DateTime TransactTime { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public OrdemInfo OrdemInfoCompra { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public OrdemInfo OrdemInfoVenda { get; set; }
    }
}
