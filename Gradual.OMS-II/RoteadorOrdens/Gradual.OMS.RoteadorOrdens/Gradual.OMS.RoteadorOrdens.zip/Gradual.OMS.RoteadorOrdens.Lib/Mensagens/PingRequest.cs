﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace Gradual.OMS.RoteadorOrdens.Lib.Mensagens
{
    /// <summary>
    /// Mensagem de ping para manutencao da conexao
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class PingRequest
    {
        /// <summary>
        /// Data e hora da requisicao de ping
        /// ---------------------------------
        /// </summary>
        [Category("Timestamp")]
        [Description("Data e hora da requisicao de ping")]
        public DateTime Timestamp {get;set;}
    }
}
