﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Gradual.OMS.RoteadorOrdens.Lib.Mensagens
{
    /// <summary>
    /// Mensagem de ping para manutencao da conexao
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class PingResponse
    {
        /// <summary>
        /// Data e hora da resposta de ping
        /// ---------------------------------
        /// </summary>
        [Category("Timestamp")]
        [Description("Data e hora da resposta de ping")]
        public DateTime Timestamp { get; set; }
    }
}
