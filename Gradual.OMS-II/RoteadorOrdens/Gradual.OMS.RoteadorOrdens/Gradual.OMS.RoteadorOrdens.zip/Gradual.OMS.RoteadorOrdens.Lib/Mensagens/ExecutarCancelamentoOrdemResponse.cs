﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

using Gradual.OMS.RoteadorOrdens.Lib.Dados;

namespace Gradual.OMS.RoteadorOrdens.Lib.Mensagens
{
    /// <summary>
    /// Mensagem de resposta à solicitação de cancelamento de ordem.
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class ExecutarCancelamentoOrdemResponse
    {
        /// <summary>
        /// OrderInfo: contém todas as informações enviadas pelo serviço de Ordens (risco)
        /// ------------------------------------------------------------------------------
        /// </summary>
        [Category("Cancelamento")]
        [Description("Contém todas as informações retornadas pelo roteador de ordens em resposta à requisição de cancelamento")]
        public DadosRetornoExecutarCancelamentoOrdem DadosRetorno { get; set; }
    }
}
