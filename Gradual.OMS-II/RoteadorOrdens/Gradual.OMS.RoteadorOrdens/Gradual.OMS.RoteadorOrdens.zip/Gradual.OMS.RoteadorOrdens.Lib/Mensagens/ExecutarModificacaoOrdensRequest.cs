﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using Gradual.OMS.RoteadorOrdens.Lib.Dados;

namespace Gradual.OMS.RoteadorOrdens.Lib.Mensagens
{
    /// <summary>
    /// Mensagem de solicitação de alteração de ordem.
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class ExecutarModificacaoOrdensRequest
    {
        /// <summary>
        /// OrderInfo: contém todas as informações enviadas pelo serviço de Ordens (risco)
        /// ------------------------------------------------------------------------------
        /// </summary>
        [Category("OrderInfo")]
        [Description("Contém todas as informações enviadas pelo serviço de Ordens (risco)")]
        public OrdemInfo info { get; set; }
    }
}
