﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using Gradual.OMS.RoteadorOrdens.Lib.Dados;

namespace Gradual.OMS.RoteadorOrdens.Lib.Mensagens
{
    /// <summary>
    /// Mensagem de solicitação de cancelamento de ordem.
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class ExecutarCancelamentoOrdemRequest
    {
        /// <summary>
        /// OrdemCancelamentoInfo: contém todas as informações enviadas pelo 
        /// serviço de Ordens (risco)
        /// --------------------------------------------------------------------
        /// </summary>
        [Category("OrdemCancelamentoInfo")]
        [Description("Contém todas as informações enviadas pelo serviço de Ordens (risco)")]
        public OrdemCancelamentoInfo info { get; set; }
    }
}
