﻿using System.ServiceModel;
using Gradual.OMS.RoteadorOrdens.Lib.Dados;

namespace Gradual.OMS.RoteadorOrdens.Lib
{
	[ServiceContract]
    public interface IRoteadorOrdensCallback
    {
        /// <summary>
        /// Callback a ser invocado quando o Roteador receber um ExecutionReport da bolsa
        /// </summary>
        /// <param name="report"></param>
		[OperationContract(IsOneWay=true)]
		void OrdemAlterada( OrdemInfo report );
		
        /// <summary>
        /// Callback a ser invocado quando um canal conectar ou desconectar da bolsa
        /// </summary>
        /// <param name="status"></param>
		[OperationContract(IsOneWay=true)]
        void StatusConexaoAlterada(StatusConexaoBolsaInfo status);
    }
}
