﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ServiceModel;
using System.Runtime.Serialization;
using Gradual.OMS.RoteadorOrdens.Lib.Mensagens;

namespace Gradual.OMS.RoteadorOrdens.Lib
{
	[ServiceContract(Namespace = "http://gradual", CallbackContract=typeof(IRoteadorOrdensCallback))]
    public interface IAssinaturasRoteadorOrdensCallback
    {
		[OperationContract]
        AssinarExecucaoOrdemResponse AssinarExecucaoOrdens(AssinarExecucaoOrdemRequest request);
		
		[OperationContract]
        AssinarStatusConexaoBolsaResponse AssinarStatusConexaoBolsa(AssinarStatusConexaoBolsaRequest request);
    }
}
