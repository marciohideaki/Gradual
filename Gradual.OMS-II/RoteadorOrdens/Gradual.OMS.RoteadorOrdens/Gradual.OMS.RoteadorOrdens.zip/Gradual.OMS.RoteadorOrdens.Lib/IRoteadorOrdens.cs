﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ServiceModel;
using System.Runtime.Serialization;
using Gradual.OMS.RoteadorOrdens.Lib.Mensagens;

namespace Gradual.OMS.RoteadorOrdens.Lib
{
    [ServiceContract(Namespace = "http://gradual")]
	public interface IRoteadorOrdens
	{
		[OperationContract]
		ExecutarOrdemResponse ExecutarOrdem(ExecutarOrdemRequest request);
		
		[OperationContract]
		ExecutarCancelamentoOrdemResponse CancelarOrdem( ExecutarCancelamentoOrdemRequest request );
		
		[OperationContract]
		ExecutarModificacaoOrdensResponse ModificarOrdem( ExecutarModificacaoOrdensRequest request );

        [OperationContract]
        PingResponse Ping(PingRequest request);
    }
}
