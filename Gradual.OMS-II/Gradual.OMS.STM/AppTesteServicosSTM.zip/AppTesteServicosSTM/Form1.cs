﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Gradual.OMS.ConectorSTM;
using Gradual.OMS.ConectorSTM.Lib;
using Gradual.OMS.Library.Servicos;
using Gradual.OMS.ConectorSTM.Lib.Mensagens;

namespace AppTesteServicosSTM
{
    public partial class Form1 : Form, IServicoSTMCallback
    {
        public Form1()
        {
            log4net.Config.XmlConfigurator.Configure();

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            IServicoSTM stmserver = Ativador.Get<IServicoSTM>(this);

            AssinarEventosSTMResponse responset = stmserver.AssinarEventosSTM(new AssinarEventosSTMRequest() );
        }

        public void OnCBLC_ConfirmacaoNegocioMegabolsa(Gradual.OMS.ConectorSTM.Lib.Mensagens.CBLCConfirmacaoNegocioMegaBolsaInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnCBLC_ConfirmacaoNegocioBovespaFIX(Gradual.OMS.ConectorSTM.Lib.Mensagens.CBLCConfirmacaoNegocioBovespaFixInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnCBLC_ControleFasesMegabolsa(Gradual.OMS.ConectorSTM.Lib.Mensagens.CBLCControleFasesMegaBolsaInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_CancelamentoNegocio(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0100NotificacaoCancelamentoNegocioInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_CriacaoNegocio(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0103CriacaoNegocioInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_NotificacaoExecucao(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0105NotificacaoExecucaoInfo info)
        {
            MEGA0105NotificacaoExecucaoInfo xxx = info;
        }

        public void OnMega_OrdemEliminada(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0138OrdemEliminadaInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_ConfirmacaoOrdem(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0172ConfirmacaoOrdemInfo info)
        {
            MEGA0172ConfirmacaoOrdemInfo xxx = info;
        }

        public void OnMega_DeclaracaoTermo(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0411DeclaracaoTermoInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_NotificacaoDeclaracaoTermo(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0412NotificacaoDeclaracaoTermoInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_NotificacaoCancelamentoTermo(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0413NotificacaoCancelamentoTermoInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_NotificacaoRejeicaoTermo(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0414NotificacaoRejeicaoTermoInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_NotificacaoExecucaoTermo(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0415NotificacaoExecucaoTermoInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnMega_NotificacaoCancelamentoNegocioTermo(Gradual.OMS.ConectorSTM.Lib.Mensagens.MEGA0417NotificacaoCancelamentoNegocioTermoInfo info)
        {
            throw new NotImplementedException();
        }

        public void OnHeartBeat()
        {
            MessageBox.Show("Chegou HeartBeat()");
        }
    }
}
