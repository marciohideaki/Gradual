﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using Gradual.Generico.Dados;
using Gradual.OMS.PlanoCliente.Lib;
using Gradual.OMS.PlanoCliente.Lib.Util;
using log4net;

namespace Gradual.OMS.PlanoCliente
{
    public class PersistenciaDB
    {
        #region Properties

        private const string _ConnectionStringName    = "OMS";
        private const string _ConnectionStringSinacor = "SINACOR";
        private const string _ConnstringCorrWin       = "CORRWIN";
        private readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #endregion

        #region Methods

        /// <summary>
        /// Consultar planos de cliente com filtro de relatório
        /// </summary>
        /// <param name="pRequest">Objeto do tipo ListarProdutosClienteRequest</param>
        /// <returns>Retorna uma lsita com filro efetuado por request</returns>
        public List<PlanoClienteInfo> ConsultarPlanoClientesFiltrado(ListarProdutosClienteRequest pRequest)
        {
            List<PlanoClienteInfo> lRetorno = new List<PlanoClienteInfo>();

            AcessaDados acesso = new AcessaDados();

            acesso.ConnectionStringName = _ConnectionStringName;

            using (DbCommand cmd = acesso.CreateCommand(CommandType.StoredProcedure, "prc_FiltrarClienteProduto_sel"))
            {
                acesso.AddInParameter(cmd, "@dt_de",      DbType.DateTime, pRequest.De);
                acesso.AddInParameter(cmd, "@dt_ate",     DbType.DateTime, pRequest.Ate);
                acesso.AddInParameter(cmd, "@id_produto", DbType.Int32,    pRequest.IdProduto);
                acesso.AddInParameter(cmd, "@cd_cblc",    DbType.Int32,    pRequest.CdCblc);

                DataTable table = acesso.ExecuteDbDataTable(cmd);

                foreach (DataRow dr in table.Rows)
                    lRetorno.Add(CriarRegistroFiltrarPlanoClientesInfo(dr));
            }

            return lRetorno;
        }

        /// <summary>
        /// Listar os produtos aderidos de um cliente específico
        /// </summary>
        /// <param name="pRequest"></param>
        /// <returns></returns>
        public List<PlanoClienteInfo> ConsultarPlanoClientes(ListarProdutosClienteRequest pRequest)
        {
            List<PlanoClienteInfo> lRetorno = new List<PlanoClienteInfo>();

            AcessaDados acesso = new AcessaDados();

            acesso.ConnectionStringName = "Seguranca";

            using (DbCommand cmd = acesso.CreateCommand(CommandType.StoredProcedure, "prc_ClienteProduto_sel"))
            {
                acesso.AddInParameter(cmd, "@ds_cpfcnpj", DbType.AnsiString, pRequest.DsCpfCnpj);

                //if (pRequest.StSituacao != null)
                acesso.AddInParameter(cmd, "@st_situacao", DbType.AnsiString, pRequest.StSituacao);

                DataTable table = acesso.ExecuteDbDataTable(cmd);

                foreach (DataRow dr in table.Rows)
                    lRetorno.Add(CriarRegistroPlanoClientesInfo(dr));
            }

            return lRetorno;
        }

        /// <summary>
        /// Listar os Produtos da da tabela
        /// </summary>
        /// <returns>Retorna uma lista de produtos</returns>
        public List<ProdutoInfo> ListarProdutos()
        {
            List<ProdutoInfo> lRetorno = new List<ProdutoInfo>();

            AcessaDados acesso = new AcessaDados();

            acesso.ConnectionStringName = _ConnectionStringName;

            using (DbCommand cmd = acesso.CreateCommand(CommandType.StoredProcedure, "prc_Produtos_lst"))
            {
                DataTable table = acesso.ExecuteDbDataTable(cmd);

                foreach (DataRow dr in table.Rows)
                    lRetorno.Add(CriarRegistroProdutosInfo(dr));
            }

            return lRetorno;
        }

        /// <summary>
        /// Inserri planos selecionados pelo cliente
        /// </summary>
        /// <param name="pRequest"></param>
        /// <returns></returns>
        public InserirProdutosClienteResponse AtualizaPlanoClienteExistente(InserirProdutosClienteRequest pRequest)
        {
            AcessaDados acesso = new AcessaDados();

            acesso.ConnectionStringName = _ConnectionStringName;

            InserirProdutosClienteResponse lRetorno = new InserirProdutosClienteResponse();

            lRetorno.LstPlanoCliente = new List<PlanoClienteInfo>();

            lRetorno.LstPlanoCliente.AddRange(pRequest.LstPlanoCliente);

            logger.Info("Passou da linha lRetorno.LstPlanoCliente = pRequest.LstPlanoCliente;");

            acesso.Conexao._ConnectionStringName = _ConnectionStringName;

            var lDbConnection = acesso.Conexao.CreateIConnection();

            lDbConnection.Open();

            DbTransaction lTrans = lDbConnection.BeginTransaction();

            try
            {

                using (DbCommand cmdins = acesso.CreateCommand(lTrans, CommandType.StoredProcedure, "prc_ClienteExistenteProduto_upd"))
                {
                    foreach (PlanoClienteInfo info in lRetorno.LstPlanoCliente)
                    {
                        cmdins.Parameters.Clear();

                        acesso.AddInParameter(cmdins, "@ds_cpfcnpj",       DbType.AnsiString, info.DsCpfCnpj);
                        acesso.AddInParameter(cmdins, "@st_situacao",      DbType.String,     info.StSituacao);
                        acesso.AddInParameter(cmdins, "@id_produto_plano", DbType.Int32,      info.IdProdutoPlano);
                        acesso.AddInParameter(cmdins, "@cd_cblc",          DbType.Int32,      info.CdCblc);
                        acesso.AddInParameter(cmdins, "@dt_adesao",        DbType.DateTime,   info.DtAdesao);

                        acesso.ExecuteNonQuery(cmdins);
                    }
                }

                lTrans.Commit();
            }
            catch (Exception ex)
            {
                lTrans.Rollback();

                logger.ErrorFormat("Error - {0} - Stacktrace - {1}", ex.Message, ex.StackTrace);
                
                throw ex;
            }

            return lRetorno;
        }

        /// <summary>
        /// Inserri planos selecionados pelo cliente
        /// </summary>
        /// <param name="pRequest"></param>
        /// <returns></returns>
        public InserirProdutosClienteResponse InserirPlanoCliente(InserirProdutosClienteRequest pRequest)
        {
            AcessaDados acesso = new AcessaDados();

            acesso.ConnectionStringName = _ConnectionStringName;

            InserirProdutosClienteResponse lRetorno = new InserirProdutosClienteResponse();

            lRetorno.LstPlanoCliente = new List<PlanoClienteInfo>();

            lRetorno.LstPlanoCliente.AddRange(pRequest.LstPlanoCliente);

            logger.Info("Passou da linha lRetorno.LstPlanoCliente = pRequest.LstPlanoCliente;");

            acesso.Conexao._ConnectionStringName = _ConnectionStringName;

            var lDbConnection = acesso.Conexao.CreateIConnection();

            lDbConnection.Open();

            DbTransaction lTrans = lDbConnection.BeginTransaction();

            try
            {

                using (DbCommand cmddel = acesso.CreateCommand(lTrans, CommandType.StoredProcedure, "prc_ClienteProduto_del"))
                {
                    cmddel.Parameters.Clear();

                    acesso.AddInParameter(cmddel, "@ds_cpfcnpj", DbType.AnsiString, (string)pRequest.LstPlanoCliente[0].DsCpfCnpj);

                    acesso.ExecuteNonQuery(cmddel);
                }
                
                using (DbCommand cmdins = acesso.CreateCommand(lTrans, CommandType.StoredProcedure, "prc_ClienteProduto_ins"))
                {
                    foreach (PlanoClienteInfo info in lRetorno.LstPlanoCliente)
                    {
                        cmdins.Parameters.Clear();

                        acesso.AddInParameter(cmdins, "@ds_cpfcnpj",       DbType.AnsiString, info.DsCpfCnpj);
                        acesso.AddInParameter(cmdins, "@dt_operacao",      DbType.DateTime,   info.DtOperacao);
                        acesso.AddInParameter(cmdins, "@st_situacao",      DbType.String,     info.StSituacao);
                        acesso.AddInParameter(cmdins, "@id_produto_plano", DbType.Int32,      info.IdProdutoPlano);

                        acesso.ExecuteNonQuery(cmdins);
                    }
                }

                lTrans.Commit();
            }
            catch (Exception ex)
            {
                lTrans.Rollback();

                logger.ErrorFormat("Error - {0} - Stacktrace - {1}", ex.Message, ex.StackTrace);
                
                throw ex;
            }

            return lRetorno;
        }

        /// <summary>
        /// Inserri planos selecionados pelo cliente, inserindo também o código cblc, data adesão 
        /// </summary>
        /// <param name="pRequest"></param>
        /// <returns></returns>
        public InserirProdutosClienteResponse InserirPlanoClienteExistente(InserirProdutosClienteRequest pRequest)
        {
            AcessaDados acesso = new AcessaDados();

            acesso.ConnectionStringName = _ConnectionStringName;

            InserirProdutosClienteResponse lRetorno = new InserirProdutosClienteResponse();

            lRetorno.LstPlanoCliente = new List<PlanoClienteInfo>();

            lRetorno.LstPlanoCliente.AddRange(pRequest.LstPlanoCliente);

            logger.Info("Passou da linha lRetorno.LstPlanoCliente = pRequest.LstPlanoCliente;");

            acesso.Conexao._ConnectionStringName = _ConnectionStringName;

            var lDbConnection = acesso.Conexao.CreateIConnection();

            lDbConnection.Open();

            DbTransaction lTrans = lDbConnection.BeginTransaction();

            try
            {
                using (DbCommand cmddel = acesso.CreateCommand(lTrans, CommandType.StoredProcedure, "prc_ClienteProduto_del"))
                {
                    cmddel.Parameters.Clear();

                    acesso.AddInParameter(cmddel, "@ds_cpfcnpj", DbType.AnsiString, pRequest.LstPlanoCliente[0].DsCpfCnpj);

                    acesso.ExecuteNonQuery(cmddel);
                }

                using (DbCommand cmdins = acesso.CreateCommand(lTrans, CommandType.StoredProcedure, "prc_ClienteExistenteProduto_ins"))
                {
                    foreach (PlanoClienteInfo info in lRetorno.LstPlanoCliente)
                    {
                        cmdins.Parameters.Clear();

                        acesso.AddInParameter(cmdins, "@ds_cpfcnpj",       DbType.AnsiString, info.DsCpfCnpj);
                        acesso.AddInParameter(cmdins, "@dt_operacao",      DbType.DateTime,   info.DtOperacao);
                        acesso.AddInParameter(cmdins, "@dt_adesao",        DbType.DateTime,   info.DtOperacao);
                        acesso.AddInParameter(cmdins, "@st_situacao",      DbType.String,     info.StSituacao);
                        acesso.AddInParameter(cmdins, "@id_produto_plano", DbType.Int32,      info.IdProdutoPlano);
                        acesso.AddInParameter(cmdins, "@cd_cblc",          DbType.Int32,      info.CdCblc);

                        acesso.ExecuteNonQuery(cmdins);
                    }
                }

                lTrans.Commit();
            }
            catch (Exception ex)
            {
                lTrans.Rollback();

                logger.ErrorFormat("Error - {0} - Stacktrace - {1}", ex.Message, ex.StackTrace);

                throw ex;
            }

            return lRetorno;
        }

        /// <summary>
        /// Atualiza o tipo de corretagem do cliente no sinacor TSCCLIBOL
        /// </summary>
        private void AtualizaPlanoCorretagemClienteSinacor(PlanoClienteInfo pRequest)
        {
            
            try
            {
                AcessaDados acesso = new AcessaDados();

                acesso.ConnectionStringName = _ConnstringCorrWin;

                string lQuery = string.Format("UPDATE TSCCLIBOL SET IN_TIPO_CORRET = 1 WHERE CD_CLIENTE = {0}", pRequest.CdCblc);

                using (DbCommand cmdUpd = acesso.CreateCommand(CommandType.Text, lQuery ))
                {
                    acesso.ExecuteNonQuery(cmdUpd);
                }

                string lQueryCus = string.Format("UPDATE TSCCLICUS SET TP_CUSTODIA = 351 WHERE CD_CLIENTE = {0}", pRequest.CdCblc);

                using (DbCommand cmdUpd = acesso.CreateCommand(CommandType.Text, lQueryCus ))
                {
                    acesso.ExecuteNonQuery(cmdUpd);
                }
            }
            catch (Exception ex)
            {
                logger.ErrorFormat("Erro em AtualizaPlanoCorretagemClienteSinacor- {0} - Stacktrace - {1}", ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        /// <summary>
        /// Atualiza a adesão do cliente para a situação normal, sem plano de corretagem especial
        /// </summary>
        /// <param name="pRequest">Request com dados do cliente</param>
        public void ExcluiAdesaoCorretagemClienteSinacor(PlanoClienteInfo pRequest)
        { 
            try
            {
                AcessaDados acesso = new AcessaDados();

                acesso.ConnectionStringName = _ConnstringCorrWin;

                string lQuery = string.Format("UPDATE TSCCLIBOL SET IN_TIPO_CORRET = 0 WHERE CD_CLIENTE = {0}", pRequest.CdCblc);

                using (DbCommand cmdUpd = acesso.CreateCommand(CommandType.Text, lQuery ))
                {
                    acesso.ExecuteNonQuery(cmdUpd);
                }

                string lQueryCus = string.Format("UPDATE TSCCLICUS SET TP_CUSTODIA = 151 WHERE CD_CLIENTE = {0}", pRequest.CdCblc);

                using (DbCommand cmdUpd = acesso.CreateCommand(CommandType.Text, lQueryCus ))
                {
                    acesso.ExecuteNonQuery(cmdUpd);
                }
            }
            catch (Exception ex)
            {
                logger.ErrorFormat("Erro em ExcluiAdesaoCorretagemClienteSinacor - {0} - Stacktrace - {1}", ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        #endregion

        #region Métodos de apoio

        private ProdutoInfo CriarRegistroProdutosInfo(DataRow dr)
        {
            return new ProdutoInfo()
            {
                DsProduto = dr["ds_produto"].DBToString(),
                IdProduto = dr["id_produto_plano"].DBToInt32()
            };
        }

        private PlanoClienteInfo CriarRegistroFiltrarPlanoClientesInfo(DataRow dr)
        {
            return new PlanoClienteInfo()
            {
                DtOperacao     = dr["dt_operacao"].DBToDateTime(),
                IdProdutoPlano = dr["id_produto_plano"].DBToInt32(),
                NomeCliente    = dr["ds_nomecliente"].DBToString(),
                DsCpfCnpj      = dr["ds_cpfcnpj"].DBToString(),
                StSituacao     = dr["st_situacao"].DBToChar(),
                NomeProduto    = dr["ds_produto"].DBToString()
            };
        }

        private PlanoClienteInfo CriarRegistroPlanoClientesInfo(DataRow dr)
        {
            return new PlanoClienteInfo() 
            {
                DtOperacao       = dr["dt_operacao"].DBToDateTime(),
                IdProdutoPlano   = dr["id_produto_plano"].DBToInt32(),
                NomeCliente      = dr["ds_nome_cliente"].DBToString(),
                StSituacao       = dr["st_situacao"].DBToChar(),
                NomeProduto      = dr["ds_produto"].DBToString(),
                DtAdesao         = dr["dt_adesao"].DBToDateTime(),
                DtUltimaOperacao = dr["dt_ultima_cobranca"].DBToDateTime(),
                CdCblc           = dr["cd_cblc"].DBToInt32(),
                DsCpfCnpj        = dr["ds_cpfcnpj"].DBToString(),
            };
        }

        #endregion
    }
}
