﻿#region Includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gradual.OMS.PlanoCliente.Lib;
using System.ServiceModel;
using log4net;
using Gradual.OMS.Library;
using Gradual.OMS.Library.Servicos;
#endregion

namespace Gradual.OMS.PlanoCliente
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class ServicoPlanoCliente : IServicoPlanoCliente, IServicoControlavel
    {
        #region Properties
        private readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private ServicoStatus _ServicoStatus = ServicoStatus.Indefinido; 
        #endregion

        #region Métodos de Busca
        /// <summary>
        /// Lista os produtos cadastrados com filtros de relatórios
        /// </summary>
        /// <param name="pRequest">Objeto de request do tipo ListarProdutosClienteRequest</param>
        /// <returns>Retorna lista de produto cadastrado com filtros de relatório</returns>
        public ListarProdutosClienteResponse ConsultarProdutosClienteFiltro(ListarProdutosClienteRequest pRequest)
        {
            ListarProdutosClienteResponse lRetorno = new ListarProdutosClienteResponse();

            try
            {
                PersistenciaDB lDb = new PersistenciaDB();

                lRetorno.LstPlanoCliente = new List<PlanoClienteInfo>();

                lRetorno.LstPlanoCliente = lDb.ConsultarPlanoClientesFiltrado(pRequest);

                lRetorno.StatusResposta = MensagemResponseStatusEnum.OK;

                lRetorno.DataResposta = DateTime.Now;

                logger.Info(string.Concat("Entrou no ConsultarProdutosCliente e listou ", lRetorno.LstPlanoCliente.Count, " produto(s)"));
            }
            catch (Exception ex)
            {
                lRetorno.StatusResposta = MensagemResponseStatusEnum.ErroPrograma;

                logger.ErrorFormat("Erro em ConsultarProdutosCliente - {0} - StackTrace - {1}", ex.Message, ex.StackTrace);
            }

            return lRetorno;
        }

        #endregion

        #region IServicoControlavel Members

        public void IniciarServico()
        {
            _ServicoStatus = ServicoStatus.EmExecucao;
            
            logger.Info("Iniciando o serviço de Planos do cliente");
        }

        public void PararServico()
        {
            _ServicoStatus = ServicoStatus.Parado;

            logger.Info("Parando o serviço de Planos do cliente");
        }

        public ServicoStatus ReceberStatusServico()
        {
            return _ServicoStatus;
        }

        #endregion

        #region IServicoPlanoCliente Members
        /// <summary>
        /// Atualiza os plano do cliente com a adesão atual do cliente
        /// </summary>
        /// <param name="pRequest"></param>
        /// <returns></returns>
        public InserirProdutosClienteResponse AtualizaPlanoClienteExistente(InserirProdutosClienteRequest pRequest)
        {
            InserirProdutosClienteResponse lRetorno = new InserirProdutosClienteResponse();
            try
            {
                PersistenciaDB lDb = new PersistenciaDB();

                lRetorno = lDb.AtualizaPlanoClienteExistente(pRequest);

                lRetorno.StatusResposta = MensagemResponseStatusEnum.OK;

                lRetorno.DataResposta = DateTime.Now;

                logger.Info(string.Concat("Entrou no AtualizaPlanoClienteExistente e inseriu ", lRetorno.LstPlanoCliente.Count, " produto(s)"));

            }
            catch (Exception ex)
            {
                lRetorno.StatusResposta = MensagemResponseStatusEnum.ErroPrograma;

                logger.ErrorFormat("Erro em AtualizaPlanoClienteExistente - {0} - StackTrace - {1}", ex.Message, ex.StackTrace);
            }

            return lRetorno;
        }

        /// <summary>
        /// Lista os produtos cadastrados no cliente selecionado
        /// </summary>
        /// <param name="pRequest">Objeto de request do tipo ListarProdutosClienteRequest</param>
        /// <returns>Retorna lista de produto cadastrado no cliente selecionado</returns>
        public ListarProdutosClienteResponse ListarProdutosCliente(ListarProdutosClienteRequest pRequest)
        {
            ListarProdutosClienteResponse lRetorno = new ListarProdutosClienteResponse();

            try
            {
                PersistenciaDB lDb = new PersistenciaDB();

                lRetorno.LstPlanoCliente = new List<PlanoClienteInfo>();

                lRetorno.LstPlanoCliente = lDb.ConsultarPlanoClientes(pRequest);

                lRetorno.StatusResposta = MensagemResponseStatusEnum.OK;

                lRetorno.DataResposta = DateTime.Now;

                logger.Info(string.Concat("Entrou no ConsultarProdutosCliente e listou ", lRetorno.LstPlanoCliente.Count, " produto(s)"));
            }
            catch (Exception ex)
            {
                lRetorno.StatusResposta = MensagemResponseStatusEnum.ErroPrograma;

                logger.ErrorFormat("Erro em ConsultarProdutosCliente - {0} - StackTrace - {1}", ex.Message, ex.StackTrace);
            }

            return lRetorno;
        }

        /// <summary>
        /// Insere os produtos selecionados pelo cliente
        /// </summary>
        /// <param name="pRequest">Objeto de request dos produtos selecionados</param>
        /// <returns>Retorna o objeto do tipo InserirProdutosClienteResponse</returns>
        public InserirProdutosClienteResponse InserirPordutosCliente(InserirProdutosClienteRequest pRequest)
        {
            InserirProdutosClienteResponse lRetorno = new InserirProdutosClienteResponse();
            try
            {
                PersistenciaDB lDb = new PersistenciaDB();

                lRetorno = lDb.InserirPlanoCliente(pRequest);

                lRetorno.StatusResposta = MensagemResponseStatusEnum.OK;

                lRetorno.DataResposta = DateTime.Now;

                logger.Info(string.Concat("Entrou no InserirPordutosCliente e inseriu ", lRetorno.LstPlanoCliente.Count, " produto(s)"));

            }
            catch (Exception ex)
            {
                lRetorno.StatusResposta = MensagemResponseStatusEnum.ErroPrograma;

                logger.ErrorFormat("Erro em InserirPordutosCliente - {0} - StackTrace - {1}", ex.Message, ex.StackTrace);
            }

            return lRetorno;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pRequest"></param>
        /// <returns></returns>
        public ExcluirProdutosClienteResponse ExcluirProdutosClienteSinacor(ExcluirProdutosClienteRequest pRequest)
        {
            ExcluirProdutosClienteResponse lRetorno = new ExcluirProdutosClienteResponse();

            try
            {
                PersistenciaDB lDb = new PersistenciaDB();

                lDb.ExcluiAdesaoCorretagemClienteSinacor(pRequest.PlanoCliente); 

                lRetorno.StatusResposta = MensagemResponseStatusEnum.OK;

                lRetorno.DataResposta = DateTime.Now;

                logger.Info(string.Concat("Entrou no ExcluirProdutosClienteSinacor e excluiu  os produtos do cliente ", pRequest.PlanoCliente.CdCblc));
            }
            catch (Exception ex)
            {
                lRetorno.StatusResposta = MensagemResponseStatusEnum.ErroPrograma;

                logger.ErrorFormat("Erro em ExcluirProdutosClienteSinacor - {0} - StackTrace - {1}", ex.Message, ex.StackTrace);
            }
            return lRetorno;
        }

        /// <summary>
        /// Insere um plano/produto (pelo portal) para o cliente que já tem o cblc 
        /// </summary>
        /// <param name="pRequest">Objeto de request InserirProdutosClienteRequest</param>
        /// <returns>Retorna o objeto inserido</returns>
        public InserirProdutosClienteResponse InserirPlanoClienteExistente(InserirProdutosClienteRequest pRequest)
        {
            InserirProdutosClienteResponse lRetorno = new InserirProdutosClienteResponse();
            try
            {
                PersistenciaDB lDb = new PersistenciaDB();

                lRetorno = lDb.InserirPlanoClienteExistente(pRequest);

                lRetorno.StatusResposta = MensagemResponseStatusEnum.OK;

                lRetorno.DataResposta = DateTime.Now;

                logger.Info(string.Concat("Entrou no InserirPlanoClienteExistente e inseriu ", lRetorno.LstPlanoCliente.Count, " produto(s)"));

            }
            catch (Exception ex)
            {
                lRetorno.StatusResposta = MensagemResponseStatusEnum.ErroPrograma;

                logger.ErrorFormat("Erro em InserirPlanoClienteExistente - {0} - StackTrace - {1}", ex.Message, ex.StackTrace);
            }

            return lRetorno;
            
        }

        /// <summary>
        /// Lista os Produtos cadastrados
        /// </summary>
        /// <returns>Lista os produtos caadstrados no banco de dados</returns>
        public ListarProdutosResponse ListarProdutos()
        {
            ListarProdutosResponse lRetorno = new ListarProdutosResponse();
            try
            {
                PersistenciaDB lDb = new PersistenciaDB();

                lRetorno.LstProdutos = new List<ProdutoInfo>();

                lRetorno.LstProdutos = lDb.ListarProdutos();

                lRetorno.StatusResposta = MensagemResponseStatusEnum.OK;

                lRetorno.DataResposta = DateTime.Now;

                logger.Info(string.Concat("Entrou no ListarProdutos e listou ", lRetorno.LstProdutos.Count, " produto(s)"));
            }
            catch (Exception ex)
            {
                lRetorno.StatusResposta = MensagemResponseStatusEnum.ErroPrograma;

                logger.ErrorFormat("Erro em ListarProdutos - {0} - StackTrace - {1}", ex.Message, ex.StackTrace);
            }

            return lRetorno;
        }

        #endregion

        public Lib.Mensagens.ConsultarClienteProdutoResponse ConsultarClienteProduto(Lib.Mensagens.ConsultarClienteProdutoRequest pRequest)
        {
            throw new NotImplementedException();
        }
    }
}
