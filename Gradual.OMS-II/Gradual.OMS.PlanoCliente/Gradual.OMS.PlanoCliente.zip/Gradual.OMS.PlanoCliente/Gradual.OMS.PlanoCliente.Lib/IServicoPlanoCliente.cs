﻿#region includes
using System.ServiceModel;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    [ServiceContract(Namespace = "http://gradual")]
    public interface IServicoPlanoCliente
    {
        [OperationContract]
        ListarProdutosClienteResponse ConsultarProdutosCliente(ListarProdutosClienteRequest pRequest);

        [OperationContract]
        ListarProdutosResponse ListarProdutos();

        [OperationContract]
        InserirProdutosClienteResponse InserirPordutosCliente(InserirProdutosClienteRequest pRequest);

        [OperationContract]
        ListarProdutosClienteResponse ConsultarProdutosClienteFiltro(ListarProdutosClienteRequest pRequest);
    }
}
