﻿#region Includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gradual.OMS.Library;
using System.Runtime.Serialization;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    [Serializable]
    [DataContract]
    public class ListarProdutosClienteResponse : MensagemResponseBase
    {
        [DataMember]
        public List<PlanoClienteInfo> LstPlanoCliente { get; set; }
    }
}
