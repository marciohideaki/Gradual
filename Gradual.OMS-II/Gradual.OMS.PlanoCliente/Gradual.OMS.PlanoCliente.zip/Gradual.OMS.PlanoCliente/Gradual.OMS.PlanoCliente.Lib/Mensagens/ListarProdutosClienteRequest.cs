﻿#region Include
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gradual.OMS.Library;
using System.Runtime.Serialization;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    [DataContract]
    [Serializable]
    public class ListarProdutosClienteRequest : MensagemRequestBase
    {
        [DataMember]
        public Nullable<int> IdCliente { get; set; }

        [DataMember]
        public DateTime De { get; set; }

        [DataMember]
        public DateTime Ate { get; set; }

        [DataMember]
        public Nullable<int> IdProduto { get; set; }
    }
}
