﻿#region Includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gradual.OMS.Library;
using System.Runtime.Serialization;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    [DataContract]
    [Serializable]
    public class InserirProdutosClienteResponse : MensagemResponseBase
    {
        [DataMember]
        public List<PlanoClienteInfo> LstPlanoCliente { get; set; }
    }
}
