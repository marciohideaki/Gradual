﻿#region Includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gradual.OMS.Library;
using System.Runtime.Serialization;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    [Serializable]
    [DataContract]
    public class ListarProdutosResponse : MensagemResponseBase
    {
        [DataMember]
        public List<ProdutoInfo> LstProdutos { get; set; }
    }
}
