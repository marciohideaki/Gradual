﻿#region Include
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    [Serializable]
    public class PlanoClienteInfo
    {
        [DataMember]
        public Nullable<int> IdCliente { get; set; }

        [DataMember]
        public string NomeCliente { get; set; }

        [DataMember]
        public Nullable<int> IdProdutoPlano { get; set; }

        [DataMember]
        public string CpfCnpj { get; set; }

        [DataMember]
        public char StAtivo { get; set; }

        [DataMember]
        public string NomeProduto { get; set; }

        [DataMember]
        public DateTime DtOperacao { get; set; }
    }
}
