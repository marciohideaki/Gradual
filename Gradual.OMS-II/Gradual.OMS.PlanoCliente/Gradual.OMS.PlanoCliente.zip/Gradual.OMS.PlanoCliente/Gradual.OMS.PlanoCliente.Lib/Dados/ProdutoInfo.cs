﻿#region Includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    [Serializable]
    public class ProdutoInfo
    {
        [DataMember]
        public int IdProduto { get; set; }

        [DataMember]
        public string DsProduto { get; set; }
    }
}
