﻿#region Include
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#endregion

namespace Gradual.OMS.PlanoCliente.Lib
{
    public class Enum
    {
        public enum eDateNull
        {
            Permite,
            DataMinValue
        }
    }
}
