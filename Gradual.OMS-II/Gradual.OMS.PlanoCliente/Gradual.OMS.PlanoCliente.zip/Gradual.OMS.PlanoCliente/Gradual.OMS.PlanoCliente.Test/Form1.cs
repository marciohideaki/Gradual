﻿#region Includes
using Gradual.OMS.PlanoCliente.Lib;
using Gradual.OMS.PlanoCliente.Lib.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Gradual.OMS.Library.Servicos;
using Gradual.OMS.PlanoCliente;
#endregion

namespace Gradual.OMS.PlanoCliente.Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, EventArgs e)
        {
            try
            {
                PersistenciaDB lServico = new PersistenciaDB();
                //IServicoPlanoCliente lServico = Ativador.Get<IServicoPlanoCliente>();

                List<PlanoClienteInfo> lRequest = new List<Lib.PlanoClienteInfo>();

                for (int i = 0; i <= 2; i++)
                {
                    lRequest.Add(new PlanoClienteInfo()
                    {
                        DtOperacao = DateTime.Now,
                        IdCliente = 31940,
                        IdProdutoPlano = (i + 1),
                        StAtivo = 'S'

                    });
                }

                InserirProdutosClienteResponse lresponse = lServico.InserirPlanoCliente(new InserirProdutosClienteRequest()
                {
                    LstPlanoCliente = lRequest
                });

                //ListarProdutosClienteResponse lProdutosClientes = lServico.ConsultarProdutosCliente(
                //                                            new ListarProdutosClienteRequest() 
                //                                            {
                //                                                IdCliente = 31940,
                //                                                De = new DateTime(2010,11,1),
                //                                                Ate = new DateTime(2010,12,24)
                //                                            });

                List<ProdutoInfo> lista = lServico.ListarProdutos();

                //if (lista.LstProdutos.Count > 0)


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
