﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Reflection;
using STCrypt;
using System.Threading;

namespace STIntegracaoPortalHB
{
    public partial class IntegracaoPortalHB : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                ValidaRequest();

                ProcessaDadosRequest();
            }
            catch (ThreadAbortException) { }
            catch (Exception ex)
            {
                string mensagem = string.Format("Erro no método: {0}.{1}. Tipo: {2}. Erro: {3}. Origem: {4}.", 
                    this.GetType().FullName, 
                    MethodInfo.GetCurrentMethod().Name,    
                    ex.GetType().Name,                     
                    ex.Message,
                    ex.StackTrace);

                LogErro.GravaLog(mensagem);

                Response.Redirect("Erro.html");
            }
        }

        private void ValidaRequest()
        {
            if (string.IsNullOrEmpty(Request.Form.Get("token")))
            {
                throw new Exception("Parâmetro obrigatório não encontrado [token]");
            }

            if( string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("segundoValidadeToken")) )
            {
                throw new Exception("Configuração não encontrada [segundoValidadeToken]");
            }

            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("EnderecoFerramenta")))
            {
                throw new Exception("Configuração não encontrada [EnderecoFerramenta]");
            }
        }

        private void ProcessaDadosRequest()
        {
            int segundosValidadeToken = Convert.ToInt32(ConfigurationManager.AppSettings["segundoValidadeToken"]);

            string tokenDescriptografado = Crypt.Descriptografa(Request.Form.Get("token"));

            string login = tokenDescriptografado.Split('|')[0];
            DateTime dataHora = Convert.ToDateTime(tokenDescriptografado.Split('|')[1]);

            if (dataHora.AddSeconds(segundosValidadeToken) >= DateTime.Now)
            {
                Session["atributoAutenticacaoAcessoDireto"] = login;
                string page = string.Format("{0}/ProcessaLoginAcessoDireto.aspx", ConfigurationManager.AppSettings.Get("EnderecoFerramenta"));
                Response.Redirect(page);
            }
            else
            {
                throw new Exception("Tempo de validade do token expirou");
            }
        }
    }
}